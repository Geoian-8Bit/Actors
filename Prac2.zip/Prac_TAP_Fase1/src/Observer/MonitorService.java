package Observer;
import Actors.Actor;
import Actors.ActorContext;
import Actors.ActorProxy;
import Actors.ActorValues;
import Message.*;

import java.time.LocalDateTime;
import java.util.*;

public class MonitorService implements Subject{

    private static MonitorService monitorService= new MonitorService();
    public static MonitorService getInstance(){ return monitorService;}
    private HashMap<String, ArrayList<ActorListener>> listeners;
    private HashMap<String, HashSet<String>> traffic;
    private HashMap<String, ArrayList<String>> logReceivedMessage;
    private HashMap<String, ArrayList<String>> logSendedMessage;
    private HashMap<Event, ArrayList<Message>> logEvents;



    public MonitorService() {
        this.listeners = new HashMap<>();
        this.traffic = new HashMap<>();
        this.logEvents = new HashMap<>();
        logEvents.putIfAbsent(Event.STOPPED, new ArrayList<Message>());
        logEvents.putIfAbsent(Event.CREATED, new ArrayList<Message>());
        logEvents.putIfAbsent(Event.ERROR, new ArrayList<Message>());
        this.logReceivedMessage = new HashMap<>();
        this.logSendedMessage = new HashMap<>();
    }

    @Override
    public void attach(String name, ActorListener listener) {

        listeners.putIfAbsent(name, new ArrayList<ActorListener>());
        ArrayList<ActorListener> aux = listeners.get(name);
        aux.add(listener);

    }

    public void attachAll(){
        listeners.clear();
        ActorContext context = ActorContext.getInstance();
        ArrayList<Actor> list = context.getAll();
        Actor aux;
        for(int i = 0; i < list.size(); i++){
            aux = list.get(i);
            listeners.putIfAbsent(aux.getNameActor(), new ArrayList<ActorListener>());
            ArrayList<ActorListener> aux2 = listeners.get(aux.getNameActor());
            aux2.add(new Panel(aux.getNameActor()));

        }

    }
    @Override
    public void dettach(String name,  ActorListener listener) {
        if(listeners.containsKey(name)){
            ArrayList<ActorListener> aux = listeners.get(name);
            aux.remove(listener);
            if(aux.size() == 0){
                listeners.remove(name);
            }
        }
    }

    public static Actor getActor (Actor actor) {
        Actor aux = actor;
        Actor antAux = null;
        while ( aux != null) {
            antAux = aux;
            aux = aux.getActor();
        }
        return antAux;
    }

    @Override
    public void notify(Message mensaje, Actor receiverActor ) {
        String msg = mensaje.getMessage();
        ActorProxy senderActor = mensaje.getName();
        ArrayList<Message> events;
        receiverActor = MonitorService.getActor(receiverActor);
        ArrayList<ActorListener> aux = listeners.get(receiverActor.getNameActor());

        if (mensaje instanceof CreateMessage) {
            for (ActorListener i : aux) {
                i.created();
            }
            events = logEvents.get(Event.CREATED);
            events.add(mensaje);
        }
        else if (mensaje instanceof QuitMessage) {
            for (ActorListener i : aux) {
                i.stop();
               }
            events = logEvents.get(Event.STOPPED);
            events.add(new QuitMessage(new ActorProxy(receiverActor.getNameActor(), receiverActor)));
        }
        else if (mensaje instanceof ErrorMessage) {
            for (ActorListener i : aux) {
                i.error();
            }
            events = logEvents.get(Event.ERROR);
            events.add(new ErrorMessage(new ActorProxy(receiverActor.getNameActor(), receiverActor)));
        }
        else if (mensaje instanceof SentMessage){
            logSendedMessage.putIfAbsent(senderActor.getNameActor(), new ArrayList<>());
            ArrayList<String> list = logSendedMessage.get(senderActor.getNameActor());
            msg = msg + " sent at " + LocalDateTime.now();
            list.add(msg);

        }
        else {

            logReceivedMessage.putIfAbsent(receiverActor.getNameActor(), new ArrayList<>());
            ArrayList<String> list = logReceivedMessage.get(receiverActor.getNameActor());
            msg = msg + " received at " + LocalDateTime.now();
            list.add(msg);

            for (ActorListener i : aux) {
                i.received();
            }
           this.addTraffic(receiverActor);
        }
    }



    public HashMap<String, HashSet<String>> getTraffic (){
        return traffic;
    }
    public HashMap<String, ArrayList<String>> getSentMessages (){return logSendedMessage;}
    public HashMap<String, ArrayList<String>> getReceivedMessages (){return logReceivedMessage;}

    public int getNumberofMessages (ActorProxy name){
        int number = 0;
        ArrayList<String> list = logSendedMessage.get(name.getNameActor());
        if(list != null)
            number = list.size();
        list = logReceivedMessage.get(name.getNameActor());
        if(list != null)
         number = number + list.size();
        return number;
    }


    public HashMap<Event, ArrayList<Message>> getEvents (){
        return  logEvents;
    }

    public HashMap<String, ArrayList<ActorListener>> getListeners() {
        return listeners;
    }

    public void addTraffic (Actor name){

        Actor actor = name;

        Queue<Message> buffer = actor.getQueue();


        if(buffer.size() < 5){
            traffic.putIfAbsent("LOW", new HashSet<String>());
            Set<String> list =  traffic.get("LOW");
            Set<String> other = traffic.get("MEDIUM");
            if (other != null)
                other.remove(actor.getNameActor());

            other = traffic.get("HIGH");
            if (other != null)
                other.remove(actor.getNameActor());


            list.add(actor.getNameActor());

        } else if (buffer.size() >= 5 && buffer.size() < 15) {
            traffic.putIfAbsent("MEDIUM", new HashSet<String>());
            HashSet<String> list = traffic.get("MEDIUM");
            Set<String> other = traffic.get("LOW");
            if (other != null)
                other.remove(actor.getNameActor());

            other = traffic.get("HIGH");
            if (other != null)
                other.remove(actor.getNameActor());


            list.add(actor.getNameActor());
        }
        else{
            traffic.putIfAbsent("HIGH", new HashSet<String>());
            HashSet<String> list = traffic.get("HIGH");
            Set<String> other = traffic.get("LOW");
            if (other != null)
                other.remove(actor.getNameActor());

            other = traffic.get("MEDIUM");
            if (other != null)
                other.remove(actor.getNameActor());


            list.add(actor.getNameActor());
        }
    }
}
