package Observer;

import Actors.Actor;
import Message.Message;

public interface Subject {
    public void attach(String name, ActorListener listener);
    public void dettach(String name, ActorListener listener);
    public void notify(Message mensaje, Actor receiverActor);
    public void attachAll();
}
