package Observer;

public interface ActorListener {

    public void created();
    public void error();
    public void stop();
    public void received();


}
