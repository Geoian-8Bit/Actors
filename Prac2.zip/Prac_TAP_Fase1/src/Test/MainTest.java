package Test;


import java.util.Scanner;

public class MainTest {
    public static void main(String[] args) throws InterruptedException {
        Scanner entrada = new Scanner(System.in);
        int option;
        MainInterface test;

        while(true) {
            System.out.println("Choose the actor model: ");
            System.out.println("[1] Ring Actor ");
            System.out.println("[2] Ping pong Actor");

            option = entrada.nextInt();
            if(option == 1 || option == 2){

                if(option == 1){
                    System.out.println("Choose the functionality that you want to test: ");
                    System.out.println("[1] Communication between actors ");
                    System.out.println("[2] Observer ");
                    System.out.println("[3] Performance");
                    option = entrada.nextInt();
                    switch (option){
                        case 1:
                            test = new TestCommunication();
                            test.testRing();
                            break;
                        case 2:
                            test = new TestObserver();
                            test.testRing();
                            break;
                        case 3:
                            test = new TestPerformance();
                            test.testRing();
                            break;
                    }
                }
                else{
                    System.out.println("Choose the functionality that you want to test: ");
                    System.out.println("[1] Communication between actors ");
                    System.out.println("[2] Decorators ");
                    System.out.println("[3] Dynamic Proxy ");
                    System.out.println("[4] Observer ");
                    option = entrada.nextInt();
                    switch (option){
                        case 1:
                            test = new TestCommunication();
                            test.testPingPong();
                            break;
                        case 2:
                            test = new TestDecorators();
                            test.testPingPong();
                            break;
                        case 3:
                            test = new TestDynamicProxy();
                            test.testPingPong();
                            break;
                        case 4:
                            test = new TestObserver();
                            test.testPingPong();
                            break;
                    }
                }
            }



        }
    }
}
