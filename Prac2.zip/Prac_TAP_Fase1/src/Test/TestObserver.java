package Test;

import Actors.ActorContext;
import Actors.ActorProxy;
import Actors.InsultActor;
import Actors.RingActor;
import Message.*;
import Observer.Event;
import Observer.MonitorService;
import Observer.Panel;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Scanner;

public class TestObserver implements MainInterface{

    @Override
    public void testRing() throws InterruptedException {
        Scanner entrada = new Scanner(System.in);
        int option, listeners;
        HashMap<String, ArrayList<String>> receivedMessage;
        HashMap<String, ArrayList<String>> sentMessage;
        HashMap<Event, ArrayList<Message>> events;
        ArrayList<Message> list;
        ArrayList<String> actor;
        ArrayList<Panel> panels = new ArrayList<Panel>();
        boolean escape = false;

        MonitorService monitor = MonitorService.getInstance();
        ActorContext context = ActorContext.getInstance();
        ActorProxy ac1 = context.SpawnActor("1", new RingActor("1", null));

        System.out.println("Choose how many actors you want in the ring (2-100)");
        option = entrada.nextInt();
        System.out.println("Choose how many actors you want to monitor");
        listeners = entrada.nextInt();
        if (listeners > option) listeners = option;

        if(option >= 2 && option <=100){
            for (int i = 1; i <= listeners; i++) {
                panels.add(new Panel(String.valueOf(i)));
                monitor.attach(String.valueOf(i),panels.get(i-1));
            }

            for(int i = 2; i <= option; i++){
                ac1.sendMessage(new AddActorMessage(ac1, String.valueOf(i)));
            }
            ac1.sendMessage(new GetInsultMessage(null,"Activate"));
        }


        while(!escape) {
            System.out.println("Choose the functionality of the monitor service that you want to test: ");
            System.out.println("[1] GetTraffic");
            System.out.println("[2] GetNumberOfMessages");
            System.out.println("[3] GetSentMessages");
            System.out.println("[4] GetReceivedMessages");
            System.out.println("[5] GetEvents");
            System.out.println("[6] Attach to all actors");
            System.out.println("[7] Cause an error");
            System.out.println("[8] Quit");
            option = entrada.nextInt();
            switch (option) {
                case 1:
                    HashMap<String, HashSet<String>> map = monitor.getTraffic();
                    HashSet<String> low = map.get("LOW");
                    HashSet<String> medium = map.get("MEDIUM");
                    HashSet<String> high = map.get("HIGH");
                    System.out.println("Actors LOW:");
                    if (low != null) {
                        for (String i : low)
                            System.out.println(i.toString());
                    }

                    System.out.println("Actors MEDIUM:");
                    if (medium != null) {
                        for (String i : medium)
                            System.out.println(i.toString());
                    }
                    System.out.println("Actors HIGH:");
                    if (high != null) {
                        for (String i : high)
                            System.out.println(i.toString());
                    }
                    break;
                case 2:
                    System.out.println("Choose the number of actor you want to get the number of messages");
                    listeners = entrada.nextInt();
                    ac1 = context.lookup(String.valueOf(listeners));
                    System.out.println("Actor "+listeners+" has: " + monitor.getNumberofMessages(ac1)+" messages");
                    break;
                case 3:
                    System.out.println("Choose the number of actor you want to get the number of messages");
                    listeners = entrada.nextInt();
                    sentMessage = monitor.getSentMessages();
                    actor = sentMessage.get(String.valueOf(listeners));
                    System.out.println("Actor "+listeners+ " sent messages:");
                    if (actor != null) {
                        for (String i : actor)
                            System.out.println(i.toString());
                    }
                    break;
                case 4:
                    System.out.println("Choose the number of actor you want to get the number of messages");
                    listeners = entrada.nextInt();
                    receivedMessage = monitor.getReceivedMessages();
                    actor = receivedMessage.get(String.valueOf(listeners));
                    System.out.println("Actor "+listeners+" received messages:");
                    if (actor != null) {
                        for (String i : actor)
                            System.out.println(i.toString());
                    }
                    break;
                case 5:
                    events = monitor.getEvents();
                    list = events.get(Event.ERROR);
                    if (list != null) {
                        for (Message i : list)
                            System.out.println("The actor " + i.getName().getNameActor() + " has performed the event " + i.getMessage().toString());
                    }
                    list = events.get(Event.CREATED);
                    if (list != null) {
                        for (Message i : list)
                            System.out.println("The actor " + i.getName().getNameActor() + " has performed the event " + i.getMessage().toString());
                    }
                    list = events.get(Event.STOPPED);
                    if (list != null) {
                        for (Message i : list)
                            System.out.println("The actor " + i.getName().getNameActor() + " has performed the event " + i.getMessage().toString());
                    }
                    break;
                case 6:
                    monitor.attachAll();
                    break;

                    case 7:
                        System.out.println("Choose the name of the actor you want to cause an error");
                        listeners = entrada.nextInt();
                        ac1 = context.lookup(String.valueOf(listeners));
                        ac1.sendMessage(new ErrorMessage(ac1));
                        break;
                case 8:
                    for (int i = 1; i <= option;i++){
                        ac1 = context.lookup(String.valueOf(i));
                        ac1.sendMessage(new QuitMessage(ac1));
                    }
                    escape = true;
                    break;
            }
        }
    }

    @Override
    public void testPingPong() throws InterruptedException {
        Scanner entrada = new Scanner(System.in);
        int option;
        HashMap<String, ArrayList<String>> receivedMessage;
        HashMap<String, ArrayList<String>> sentMessage;
        HashMap<Event, ArrayList<Message>> events;
        ArrayList<Message> list;
        ArrayList<String> actor;
        boolean escape = false;

        MonitorService monitor = MonitorService.getInstance();
        Panel p = new Panel("1");
        monitor.attach("1",p);
        System.out.println("We are going to monitor actor 1");

        ActorContext context = ActorContext.getInstance();
        ActorProxy ac1 = context.SpawnActor("1",  new InsultActor("1"));
        ActorProxy ac2 = context.SpawnActor("2", new InsultActor("2"));
        ac1.sendMessage(new GetInsultMessage(ac2, "Activate"));


        while(!escape) {
            System.out.println("Choose the functionality of the monitor service that you want to test: ");
            System.out.println("[1] GetTraffic");
            System.out.println("[2] GetNumberOfMessages");
            System.out.println("[3] GetSentMessages");
            System.out.println("[4] GetReceivedMessages");
            System.out.println("[5] GetEvents");
            System.out.println("[6] Cause an error");
            System.out.println("[7] Quit");
            option = entrada.nextInt();
            switch (option) {
                case 1:
                    HashMap<String, HashSet<String>> map = monitor.getTraffic();
                    HashSet<String> low = map.get("LOW");
                    HashSet<String> medium = map.get("MEDIUM");
                    HashSet<String> high = map.get("HIGH");
                    System.out.println("Actors LOW:");
                    if (low != null) {
                        for (String i : low)
                            System.out.println(i.toString());
                    }

                    System.out.println("Actors MEDIUM:");
                    if (medium != null) {
                        for (String i : medium)
                            System.out.println(i.toString());
                    }
                    System.out.println("Actors HIGH:");
                    if (high != null) {
                        for (String i : high)
                            System.out.println(i.toString());
                    }
                    break;
                case 2:
                    System.out.println("actor 1 have: " + monitor.getNumberofMessages(ac1));
                    break;
                case 3:
                    sentMessage = monitor.getSentMessages();
                    actor = sentMessage.get("1");
                    System.out.println("Actor 1 sent messages:");
                    if (actor != null) {
                        for (String i : actor)
                            System.out.println(i.toString());
                    }
                    break;
                case 4:
                    receivedMessage = monitor.getReceivedMessages();
                    actor = receivedMessage.get("1");
                    System.out.println("Actor 1 received messages:");
                    if (actor != null) {
                        for (String i : actor)
                            System.out.println(i.toString());
                    }
                    break;
                case 5:
                    events = monitor.getEvents();
                    list = events.get(Event.ERROR);
                    if (list != null) {
                        for (Message i : list)
                            System.out.println("The actor " + i.getName().getNameActor() + " has performed the event " + i.getMessage().toString());
                    }
                    list = events.get(Event.CREATED);
                    if (list != null) {
                        for (Message i : list)
                            System.out.println("The actor " + i.getName().getNameActor() + " has performed the event " + i.getMessage().toString());
                    }
                    list = events.get(Event.STOPPED);
                    if (list != null) {
                        for (Message i : list)
                            System.out.println("The actor " + i.getName().getNameActor() + " has performed the event " + i.getMessage().toString());
                    }
                    break;
                case 6:
                    ac1 = context.lookup("1");
                    ac1.sendMessage(new ErrorMessage(ac1));
                    break;
                case 7:
                    ac1.sendMessage(new QuitMessage(ac2));
                    ac2.sendMessage(new QuitMessage(ac1));
                    escape = true;
                    break;
            }
        }
    }
}