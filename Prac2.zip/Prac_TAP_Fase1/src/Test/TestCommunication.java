package Test;

import Actors.*;
import Message.*;

import java.util.Scanner;

import static java.lang.Thread.sleep;

public class TestCommunication implements MainInterface{

    public void testRing() throws InterruptedException {
        Scanner entrada = new Scanner(System.in);
        Message mensaje;
        int numAc = 2;
        int option;
        String exit;
        ActorProxy proxy;
        boolean quit = false;
        ActorContext context = ActorContext.getInstance();
        ActorProxy ac1 = context.SpawnActor("1", new RingActorPrint("1", null));

        System.out.println("Choose how many actors you want in the ring (2-10)");
        option = entrada.nextInt();


        if(option >= 2 && option <=10){

            for(int i = 2; i <= option; i++){
                mensaje = new AddActorMessage(ac1, String.valueOf(i));
                ac1.sendMessage(mensaje);
            }
            mensaje = new GetInsultMessage(null,"Activate");
            ac1.sendMessage(mensaje);
        }

        System.out.println("Press X to stop the test");
        while (!quit){
            exit = entrada.nextLine();
            if(exit.equals("x") || exit.equals("X"))
                quit = true;
            sleep(2000);
        }

        for (int i = 1; i <= option;i++){
            proxy = context.lookup(String.valueOf(i));
            proxy.sendMessage(new QuitMessage(proxy));
        }

    }

    public void testPingPong() throws InterruptedException {
        Scanner entrada = new Scanner(System.in);
        String message;
        int option;
        boolean quit = false;
        ActorProxy proxy;
        ActorContext context = ActorContext.getInstance();
        ActorProxy ac1 = context.SpawnActor("Ping", new InsultActorPrint("Ping"));
        ActorProxy ac2 = context.SpawnActor("Pong", new InsultActorPrint("Pong"));
        RespondProxy requestProxy = new RespondProxy("Respond Proxy");
        ActorProxy respondProxy = context.SpawnActor("Respond Proxy", requestProxy);

        ac1.sendMessage(new GetInsultMessage(ac2, "Activate"));

        while (!quit) {

            System.out.println("Choose the type of message:");
            System.out.println("[1] Get All Insults");
            System.out.println("[2] Add Insult");
            System.out.println("[3] Respond Proxy");
            System.out.println("[4] Quit");
            option = entrada.nextInt();
            if (option == 1 || option == 2) {
                System.out.println("Press 1 to choose actor Ping or press 2 to choose actor Pong");
                if (option == 1) {
                    option = entrada.nextInt();
                    if (option == 1)
                        ac1.sendMessage(new GetAllInsultsMessage(ac2));
                    if (option == 2)
                        ac2.sendMessage(new GetAllInsultsMessage(ac1));
                }
                else if (option == 2) {
                    option = entrada.nextInt();
                    System.out.println("Write the insult that you want to add");
                    message = entrada.next();
                    if (option == 1)
                        ac1.sendMessage(new AddInsultMessage(ac2, message));
                    if (option == 2)
                        ac2.sendMessage(new AddInsultMessage(ac2, message));
                }

            }
            else if (option == 3){
                ac1.sendMessage(new GetInsultMessage(respondProxy,"Respond Test"));
                System.out.println("Main receives: " + requestProxy.read());
            }
            else if (option == 4) {
                proxy = context.lookup("Pong");
                proxy.sendMessage(new QuitMessage(proxy));
                proxy = context.lookup("Ping");
                proxy.sendMessage(new QuitMessage(proxy));
                quit = true;
            }

        }
        sleep(3000);
    }
}