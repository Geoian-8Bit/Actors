package Dynamic;

import Actors.ActorProxy;

public class InsultServiceImp implements InsultService{

    @Override
    public void addInsult(String insult) {
        System.out.println("I am adding insult");
    }

    @Override
    public void getInsult(ActorProxy actor) {
        System.out.println("I am sending insult");
    }

    @Override
    public void getAllInsult() {
        System.out.println("I am sending all insults");
    }

    public void quit (){System.out.println("I am stopping");}
}
