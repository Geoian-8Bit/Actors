package Message;

import Actors.ActorProxy;

public interface Message {

    public ActorProxy getName();

    public void setName(ActorProxy name);

    public String getMessage();

    public void setMessage(String message);


}
