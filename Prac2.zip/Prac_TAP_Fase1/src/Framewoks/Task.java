package Framewoks;

import Actors.ActorContext;
import Actors.ActorProxy;
import Observer.MonitorService;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;

public class Task extends Thread {

    private JProgressBar progressBar;
    private Prova prova;
    private String nameActor;
    private JLabel numberMsg;

    private JTextArea receivedMsg, sentMsg;

    public Task (Prova prova) {
        this.prova = prova;
        this.progressBar = prova.getProgressBar();
        this.numberMsg = prova.getNumberMsg();
        this.receivedMsg = prova.getReceivedMsg();
        this.sentMsg = prova.getSentMsg();
    }

    public void progressBar () {
        this.start();
    }

    public void run () {
        ActorContext context = ActorContext.getInstance();
        MonitorService monitor = MonitorService.getInstance();
        HashMap<String, HashSet<String>> map = monitor.getTraffic();
        HashSet<String> low;
        HashSet<String> medium;
        HashSet<String> high;
        HashMap<String, ArrayList<String>> received;
        ActorProxy actor;
        ArrayList<String> list1;
        ArrayList<String> list2;
        int number;
        int progress = 0;
        String aux = "";

        while (true) {
            nameActor = prova.getActorAttached();
            actor = context.lookup(nameActor);

            if (actor != null) {
                number = monitor.getNumberofMessages(actor);
                numberMsg.setText(String.valueOf(number));
                received = monitor.getReceivedMessages();
                list1 = received.get(nameActor);

                if (list1 != null) {
                    list1 = (ArrayList<String>)list1.clone();
                    for (String i : list1)
                        aux = aux + i + "\n";
                    receivedMsg.setText(aux);
                    aux = "";

                }

                received = monitor.getSentMessages();
                list2 = received.get(nameActor);
                if (list2 != null) {
                    list2 = (ArrayList<String>)list2.clone();
                    for (String i : list2)
                        aux = aux + i + "\n";
                    sentMsg.setText(aux);
                    aux = "";
                }

            }

            low = map.get("LOW");
            medium = map.get("MEDIUM");
            high = map.get("HIGH");
            if (low != null ) {
                if (low.size() != 0)
                    progress = 33;

            }
            if (medium != null ) {
                if (medium.size() != 0)
                    progress = 66;

            }
            if (high != null ) {
                if (high.size() != 0)
                    progress = 100;

            }

            progressBar.setValue(progress);
            try {
                sleep(500);
            } catch (InterruptedException e) {
                throw new RuntimeException(e);
            }
        }
    }
}
