package Framewoks;
import Actors.ActorContext;
import Actors.ActorProxy;
import Actors.RingActor;
import Message.AddActorMessage;
import Observer.MonitorService;
import Observer.Panel;

import javax.swing.*;
import java.awt.*;
import java.util.HashMap;
import java.util.HashSet;

public class MainFrameworks extends Thread{



    public static void main (String[] args) {
        JProgressBar progressBar;

        int i = 2;
        ActorContext context = ActorContext.getInstance();
        ActorProxy ac1 = context.SpawnActor("1", new RingActor("1", null));
        ac1.sendMessage(new AddActorMessage(ac1, String.valueOf(i)));
        Prova prova = new Prova();
        prova.createUIComponents();
        progressBar = prova.getProgressBar();
        Task progress = new Task(prova);
        progress.progressBar();
        prova.setSize (600,600);
        prova.setVisible(true);
    }
}
