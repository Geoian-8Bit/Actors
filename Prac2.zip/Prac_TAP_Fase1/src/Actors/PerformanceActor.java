package Actors;

import Message.*;
import Observer.ActorListener;
import Observer.MonitorService;

import java.util.*;

public class PerformanceActor extends Thread implements Actor {

    private final int numActors = 3;
    private String name;
    private ActorProxy nextActor;
    private Queue <Message> readBuffer;

    private List<String> listInsults;

    private final String [] listPred = new String[]{"Fuck", "Dumb", "Bastard", "Bitch", "Shit"};

    public PerformanceActor(String name, ActorProxy nextActor){
        this.name = name;
        this.readBuffer = new LinkedList<>();
        this.nextActor = nextActor;
        listInsults = new LinkedList<String>();
        for(int i = 0; i < listPred.length; i++){
            listInsults.add(listPred[i]);
        }
    }

    @Override
    public void sendMessage(Message message) {
        readBuffer.add(message);
    }

    public void readMessage() {
        this.start();
    }

    @Override
    public Actor getActor() {
        return null;
    }

    @Override
    public String getNameActor() {
        return name;
    }

    @Override
    public Queue<Message> getQueue() {
        return readBuffer;
    }

    public void run(){
        String msg, randInsult;
        ActorProxy name;
        Message mensaje;
        Random rand;
        int randPosInsult;
        ActorContext context = ActorContext.getInstance();
        ActorProxy newAc;

        while(true){
                mensaje = readBuffer.poll();
                if (mensaje != null) {
                    notify (mensaje);
                    msg = mensaje.getMessage();
                    name = mensaje.getName();
                    if (mensaje instanceof GetInsultMessage) {
                        if (nextActor.getNameActor().equals("1") && msg.equals("Proxy")) {
                            ActorProxy proxy = context.lookup("Respond Proxy");
                            nextActor.sendMessage(new GetInsultMessage(context.lookup(this.name), msg));
                            proxy.sendMessage(new GetInsultMessage(context.lookup(this.name), "1"));
                        } else {
                            if (msg.equals("Proxy")) {
                                nextActor.sendMessage(new GetInsultMessage(context.lookup(this.name), msg));
                            } else {
                                rand = new Random();
                                randPosInsult = rand.nextInt(listInsults.size());
                                randInsult = listInsults.get(randPosInsult);
                                mensaje = new GetInsultMessage(context.lookup(this.name), randInsult);
                                nextActor.sendMessage(mensaje);
                            }
                        }
                    }
                    if (mensaje instanceof AddActorMessage) {
                        if (nextActor == null) {
                            newAc = context.SpawnActor(msg, new PerformanceActor(msg, context.lookup(this.name)));
                            nextActor = newAc;
                        } else if (nextActor.getNameActor().equals(name.getNameActor())) {
                            newAc = context.SpawnActor(msg, new PerformanceActor(msg, nextActor));
                            nextActor = newAc;
                        } else {
                            nextActor.sendMessage(new AddActorMessage(name, msg));
                        }
                    }
                    if (mensaje instanceof QuitMessage) {
                        try {
                            join();
                        } catch (InterruptedException e) {
                            throw new RuntimeException(e);
                        }
                    }
                    if (mensaje instanceof ErrorMessage) {
                        try {
                            join();
                        } catch (InterruptedException e) {
                            throw new RuntimeException(e);
                        }
                    }
                }
                try {
                    sleep(10);
                } catch (InterruptedException e) {
                    throw new RuntimeException(e);
                }
        }
    }

    public void notify (Message message) {
        MonitorService monitor = MonitorService.getInstance();
        HashMap<String, ArrayList<ActorListener>> listeners = monitor.getListeners();
        Actor aux = this;
        Actor antAux = null;
        while ( aux != null) {
            antAux = aux;
            aux = aux.getActor();
        }
        if(listeners.containsKey(antAux.getNameActor())){
            monitor.notify(message, antAux);
        }
    }

}
