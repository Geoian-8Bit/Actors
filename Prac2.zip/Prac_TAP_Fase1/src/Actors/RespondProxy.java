package Actors;

import Message.Message;

import java.util.LinkedList;
import java.util.Queue;

import static java.lang.Thread.sleep;

public class RespondProxy implements Actor {


    private String name;
    private Queue<Message> readBuffer;


    public RespondProxy(String name){
        this.name = name;

        readBuffer = new LinkedList<Message>();
    }

    @Override
    public void sendMessage(Message message) {
        readBuffer.add(message);
    }

    @Override
    public void readMessage() {

    }

    @Override
    public Actor getActor() {
        return null;
    }

    @Override
    public String getNameActor() {
        return name;
    }

    @Override
    public Queue<Message> getQueue() {
        return null;
    }

    public String read() throws InterruptedException {
        String msg, name;
        Message mensaje;

        while(true){
            if(!readBuffer.isEmpty()) {
                mensaje = readBuffer.poll();
                msg = mensaje.getMessage();
                return msg;
            }
            sleep(1);
        }
    }


}
