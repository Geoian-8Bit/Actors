package Observer;

public enum Event {
     CREATED, STOPPED, ERROR  ;
}
