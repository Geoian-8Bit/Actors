package Decorators;

import Actors.Actor;
import Message.Message;

import java.util.ArrayList;
import java.util.List;
import java.util.Queue;
import java.util.stream.Stream;

public class EncryptionDecorator implements Actor {
    private Actor actor;

    public EncryptionDecorator(Actor actor) {
        this.actor = actor;
    }

    public void sendMessage(Message message){
        String msg;
        List<Character> msgEnc = new ArrayList<>();

        msg = message.getMessage();
        Stream<Integer> streamMsg = msg.chars().boxed();
        streamMsg.forEach(v -> {v = (v + msg.length()); msgEnc.add((char)(v+0));});
        StringBuilder msgLamb = new StringBuilder();
        msgEnc.stream().forEach(v -> msgLamb.append(v));
        String msgFin = msgLamb.toString();
        message.setMessage(msgFin);
        System.out.println("Encrypted message is: " + msgFin);

        actor.sendMessage(message);
    }

    public Message decrypt (Message message){
        String msg;

        List<Character> msgEnc = new ArrayList<>();
        msg = message.getMessage();
        Stream<Integer> streamMsg = msg.chars().boxed();
        streamMsg.forEach(v -> {v = (v - msg.length()); msgEnc.add((char)(v+0));});
        StringBuilder msgLamb = new StringBuilder();
        msgEnc.stream().forEach(v -> msgLamb.append(v));
        String msgFin = msgLamb.toString();
        message.setMessage(msgFin);

        return message;
    }

    @Override
    public void readMessage() {
        actor.readMessage();
    }

    public Actor getActor() {
        return actor;
    }

    @Override
    public String getNameActor() {
        return null;
    }


    @Override
    public Queue<Message> getQueue() {
        return null;
    }
}
