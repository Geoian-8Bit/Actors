package Decorators;

import Actors.Actor;
import Actors.ActorContext;
import Actors.ActorProxy;
import Message.Message;

import java.util.Queue;

public class FirewallDecorator implements Actor {

    private Actor actor;

    public FirewallDecorator(Actor actor) {
        this.actor = actor;
    }

    public void sendMessage(Message message){
        ActorContext context = ActorContext.getInstance();
        ActorProxy aux = context.lookup(message.getName().getNameActor());
        if(aux != null){
            actor.sendMessage(message);
        }
        else{
            System.out.println("Firewall activated " + message.getName().getNameActor() + " is not registered\n");
        }
    }

    @Override
    public void readMessage() {
        actor.readMessage();
    }

    public Actor getActor() {
        return actor;
    }

    @Override
    public String getNameActor() {
        return null;
    }

    @Override
    public Queue<Message> getQueue() {
        return null;
    }
}
