package Decorators;

import Actors.Actor;
import Message.AddClosureMessage;
import Message.Message;

import java.util.Queue;
import java.util.function.Predicate;


public class LambdaFirewallDecorator <T>implements Actor {

    private Actor actor;

    public LambdaFirewallDecorator(Actor actor) {
        this.actor = actor;
    }

    public  void sendMessage (Message msg) {

       if(msg instanceof AddClosureMessage){
           AddClosureMessage aux = (AddClosureMessage) msg;
           Predicate<T> predicate =  aux.getPredicate();
           if (predicate.test((T)msg.getMessage())) {
               System.out.println("The LambdaFirewall has sent the message");
               actor.sendMessage(msg);
           }
           else
               System.out.println("The LambdaFirewall has refused the message " +msg.getMessage());
       }
       else {
           actor.sendMessage(msg);
       }

    }

    @Override
    public void readMessage() {
        actor.readMessage();
    }

    public Actor getActor() {
        return actor;
    }

    @Override
    public String getNameActor() {
        return null;
    }

    @Override
    public Queue<Message> getQueue() {
        return null;
    }
}
