package Dynamic;

import Actors.ActorProxy;
import Message.*;

import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Method;
import java.lang.reflect.Proxy;


public class DynamicProxy implements InvocationHandler{
    private Object target = null;
    private ActorProxy actor;
    public static Object newInstance(Object target, ActorProxy actor){
        Class targetClass = target.getClass();
        Class interfaces[] = targetClass.getInterfaces();
        return Proxy. newProxyInstance(targetClass.getClassLoader(),
                interfaces, new DynamicProxy(target, actor));
    }
    private DynamicProxy(Object target, ActorProxy actor) {
        this.target = target;
        this.actor = actor;
    }

    public Object invoke(Object proxy, Method method, Object[] args) throws Throwable{
        Object invocationResult = null;
        Message mensaje;
        try
        {

            String name = method.getName();
            if("addInsult".equals(name)) {
                mensaje = new AddInsultMessage(actor, (String) args[0]);
                actor.sendMessage(mensaje);

            } else if("getInsult".equals(name)) {
                mensaje = new GetInsultMessage((ActorProxy) args[0], "Activate ");
                actor.sendMessage(mensaje);

            } else if("getAllInsult".equals(name)) {
                mensaje = new GetAllInsultsMessage(actor);
                actor.sendMessage(mensaje);
            } else if("quit".equals(name)){
                mensaje = new QuitMessage(actor);
                actor.sendMessage(mensaje);
            }
            else {
                throw new IllegalStateException(String.valueOf(method));
            }
        }
        catch(Exception e)
        {
            System.err.println("Invocation of " + method.getName() + " failed");
        }
        finally{
            return invocationResult;
        }
    }

}
