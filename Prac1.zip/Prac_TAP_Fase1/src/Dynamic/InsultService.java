package Dynamic;

import Actors.ActorProxy;

public interface InsultService {
    void addInsult(String insult);
    void getInsult(ActorProxy actor);
    void getAllInsult();
    void quit();
}
