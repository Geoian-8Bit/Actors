package Message;

import Actors.ActorProxy;

import java.util.function.Predicate;

public class AddClosureMessage <T> implements Message{

    ActorProxy actor;
    String message;
    Predicate<T> predicate;

    public AddClosureMessage(ActorProxy actor, String message, Predicate<T> predicate) {
        this.actor = actor;
        this.message = message;
        this.predicate = predicate;
    }

    @Override
    public ActorProxy getName() {
        return actor;
    }

    @Override
    public void setName(ActorProxy name) {
        this.actor = name;
    }



    @Override
    public String getMessage() {
        return message;
    }
    public Predicate<T> getPredicate(){
        return predicate;
    }

    @Override
    public void setMessage(String message) {
        this.message = message;
    }
}
