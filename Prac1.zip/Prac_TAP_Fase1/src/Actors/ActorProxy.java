package Actors;

import Message.Message;

import java.util.Queue;

public class ActorProxy implements Actor {

    private Actor actor;
    private String name;

    public ActorProxy(String name, Actor actor){
        this.name = name;
        this.actor = actor;
    }

    public Actor getActor() {
        return actor;
    }

    @Override
    public String getNameActor() {
        return name;
    }

    @Override
    public Queue<Message> getQueue() {
        return null;
    }


    public void setName(String name) {
        this.name = name;
    }

    @Override
    public void sendMessage(Message message) {
        actor.sendMessage(message);
    }

    @Override
    public void readMessage() {

    }


}
