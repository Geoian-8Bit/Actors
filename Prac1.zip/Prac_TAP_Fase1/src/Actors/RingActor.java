package Actors;

import Decorators.EncryptionDecorator;
import Message.*;
import Observer.ActorListener;
import Observer.MonitorService;

import java.util.*;

public class RingActor extends Thread implements Actor {

    private String name;
    private ActorProxy nextActor;
    private Queue <Message> readBuffer;

    private List<String> listInsults;

    private final String [] listPred = new String[]{"Fuck", "Dumb", "Bastard", "Bitch", "Shit"};

    public RingActor(String name, ActorProxy nextActor){
        this.name = name;
        this.readBuffer = new LinkedList<>();
        this.nextActor = nextActor;
        listInsults = new LinkedList<String>();
        for(int i = 0; i < listPred.length; i++){
            listInsults.add(listPred[i]);
        }
    }

    @Override
    public void sendMessage(Message message) {
        readBuffer.add(message);
    }

    public void readMessage() {
        this.start();
    }

    @Override
    public Actor getActor() {
        return null;
    }

    @Override
    public String getNameActor() {
        return name;
    }

    @Override
    public Queue<Message> getQueue() {
        return readBuffer;
    }

    public void run(){
        String msg, randInsult;
        ActorProxy name;
        Message mensaje;
        Random rand;
        int randPosInsult;
        Actor me;
        EncryptionDecorator enc;
        boolean encripta = false;
        ActorContext context = ActorContext.getInstance();
        ActorProxy newAc;

        while(true){
            mensaje = readBuffer.poll();
            if(mensaje != null) {

                notify (mensaje);
                me = context.lookup(this.name).getActor();
                while (!encripta && me != null) {
                    if (me instanceof EncryptionDecorator) {
                        enc = new EncryptionDecorator(new ActorProxy("",this));
                        mensaje = enc.decrypt(mensaje);
                        encripta = true;
                    }
                    me = me.getActor();
                }
                encripta = false;
                msg = mensaje.getMessage();
                name = mensaje.getName();

                if (mensaje instanceof GetInsultMessage) {
                    rand = new Random();
                    randPosInsult = rand.nextInt(listInsults.size());
                    randInsult = listInsults.get(randPosInsult);
                    mensaje = new GetInsultMessage(context.lookup(this.name), randInsult);
                    nextActor.sendMessage(mensaje);
                    notify (new SentMessage(context.lookup(this.name), randInsult));
                }
                if(mensaje instanceof AddActorMessage){
                    if(nextActor == null){
                        newAc = context.SpawnActor(msg, new RingActor(msg,context.lookup(this.name)));
                        nextActor = newAc;
                    }
                    else if(nextActor.getNameActor().equals(name.getNameActor()) ){
                        newAc = context.SpawnActor(msg, new RingActor(msg,nextActor));
                        nextActor = newAc;
                    }
                    else{
                        nextActor.sendMessage(new AddActorMessage(name, msg));
                    }
                }
                if (mensaje instanceof QuitMessage) {
                    try {
                        join();
                    } catch (InterruptedException e) {
                        throw new RuntimeException(e);
                    }
                }
            }
            try {
                sleep(2000);
            } catch (InterruptedException e) {
                throw new RuntimeException(e);
            }
        }
    }

    public void notify (Message message) {
        MonitorService monitor = MonitorService.getInstance();
        HashMap<String, ArrayList<ActorListener>> listeners = monitor.getListeners();
        Actor aux = this;
        Actor antAux = null;
        while ( aux != null) {
            antAux = aux;
            aux = aux.getActor();
        }
        if(listeners.containsKey(antAux.getNameActor())){
            monitor.notify(message, antAux);
        }
    }

}
