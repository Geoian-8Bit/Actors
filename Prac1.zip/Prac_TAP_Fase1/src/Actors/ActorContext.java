package Actors;

import Message.CreateMessage;
import Message.Message;
import Observer.ActorListener;
import Observer.MonitorService;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Set;

public class ActorContext {
    private static ActorContext actorcontext = new ActorContext();
    private HashMap<String, ActorValues> listActors;

    private ActorContext(){
        listActors = new HashMap <String, ActorValues> ();
    }

    public static ActorContext getInstance(){ return actorcontext;}

    public ActorProxy SpawnActor(String name, Actor actor){
        ActorValues aux = new ActorValues(actor, name);
        listActors.put(name,aux);
        actor.readMessage();
        ActorProxy ProxyActor = new ActorProxy(name, actor);
        CreateMessage addMessage = new CreateMessage(ProxyActor);
        notify(addMessage);

        return ProxyActor;

    }

    public ActorProxy lookup(String name){

        ActorValues aux = listActors.get(name);
        if(aux != null){
            ActorProxy proxyActor = new ActorProxy(name, aux.getActor());
            return proxyActor;
        }
        return null;
    }

    public String getNames() {
        return "ActorContext{" +
                "AContextName=" + listActors.keySet() +
                '}';
    }
    public ArrayList<Actor> getAll(){

        //Collection coll = listActors.values();
        ArrayList<Actor> aux = new ArrayList<>();
        Set<String> keys = listActors.keySet();
        for (String key: keys) {
            aux.add(listActors.get(key).getActor());
        }

        return aux;
    }

    public void notify (Message message) {
        MonitorService monitor = MonitorService.getInstance();
        HashMap<String, ArrayList<ActorListener>> listeners = monitor.getListeners();
        Actor aux = message.getName();
        Actor antAux = null;
        while ( aux != null) {
            antAux = aux;
            aux = aux.getActor();
        }
        if(listeners.containsKey(antAux.getNameActor())){
            monitor.notify(message, antAux);
        }
    }

}