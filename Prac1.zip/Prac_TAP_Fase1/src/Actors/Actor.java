package Actors;

import Message.Message;

import java.util.Queue;

public interface Actor{
    public void sendMessage(Message message);
    public void readMessage();

    public Actor getActor();
    public String getNameActor();
    public Queue<Message> getQueue();

}
