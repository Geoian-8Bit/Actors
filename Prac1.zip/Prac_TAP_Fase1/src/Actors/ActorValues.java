package Actors;

public class ActorValues {
    private Actor actor;
    private String name;

    public ActorValues (Actor actor, String name) {
        this.actor = actor;
        this.name = name;
    }

    public Actor getActor() {
        return actor;
    }

    public String getName() {
        return name;
    }

}
