package Test;

import Actors.ActorContext;
import Actors.ActorProxy;
import Actors.InsultActor;
import Dynamic.DynamicProxy;
import Dynamic.InsultService;
import Dynamic.InsultServiceImp;

import java.util.Scanner;

import static java.lang.Thread.sleep;


public class TestDynamicProxy implements MainInterface{

    public void testRing() throws InterruptedException {

    }

    public void testPingPong() throws InterruptedException {
        Scanner entrada = new Scanner(System.in);
        String message;
        int option;
        boolean quit = false;
        ActorContext context = ActorContext.getInstance();
        ActorProxy ac1 = context.SpawnActor("Ping", new InsultActor("Ping"));
        ActorProxy ac2 = context.SpawnActor("Pong", new InsultActor("Pong"));
        InsultService insulter1 = (InsultService) DynamicProxy.newInstance(new InsultServiceImp(), ac1);
        InsultService insulter2 = (InsultService) DynamicProxy.newInstance(new InsultServiceImp(), ac2);

        insulter1.getInsult(ac2);

        while (!quit) {

            System.out.println("Choose the type of message:");
            System.out.println("[1] Get All Insults");
            System.out.println("[2] Add Insult");
            System.out.println("[3] Quit");
            option = entrada.nextInt();
            if (option == 1 || option == 2) {
                System.out.println("Press 1 to choose actor Ping or press 2 to choose actor Pong");
                if (option == 1) {
                    option = entrada.nextInt();
                    if (option == 1)
                        insulter1.getAllInsult();

                    if (option == 2)
                        insulter2.getAllInsult();

                }
                else if (option == 2) {
                    option = entrada.nextInt();
                    System.out.println("Write the insult that you want to add");
                    message = entrada.next();
                    if (option == 1)
                        insulter1.addInsult(message);

                    if (option == 2)
                        insulter2.addInsult(message);
                }

            }

            else if (option == 3) {
               insulter1.quit();
               insulter2.quit();
               quit = true;
            }

        }
        sleep(3000);

    }
}
