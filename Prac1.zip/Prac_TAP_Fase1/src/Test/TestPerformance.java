package Test;

import Actors.ActorContext;
import Actors.ActorProxy;
import Actors.PerformanceActor;
import Actors.RespondProxy;
import Message.AddActorMessage;
import Message.GetInsultMessage;
import Message.QuitMessage;

import java.util.Scanner;

import static java.lang.Thread.sleep;

public class TestPerformance implements MainInterface {
    public void testRing() throws InterruptedException {

        Scanner entrada = new Scanner(System.in);
        int option;
        boolean escape = false;
        int rounds= 0;
        ActorContext context = ActorContext.getInstance();
        ActorProxy ac1 = context.SpawnActor("1", new PerformanceActor("1", null));
        while(!escape) {
            System.out.println("Choose the feature that you want to validate");
            System.out.println("[1] Performance in number of messages that the Actor System can process");
            System.out.println("[2] Time to process 100 entire rounds in a ring of 100 nodes");
            System.out.println("[3] Quit");
            option = entrada.nextInt();
            if (option == 1) {
                for (int i = 2; i <= 50; i++) {
                    ac1.sendMessage(new AddActorMessage(ac1, String.valueOf(i)));
                    sleep(100);
                }
                System.out.println("How many messages you want the actor system to process?");
                option = entrada.nextInt();
                for (int i = 0; i <= option; i++) {
                    ac1.sendMessage(new GetInsultMessage(ac1, String.valueOf(i)));
                    sleep(100);
                }
                System.out.println("The actor system has been able to process " + option + " messages");

            } else if (option == 2) {
                rounds = 0;
                RespondProxy requestProxy = new RespondProxy("Respond Proxy");
                context.SpawnActor("Respond Proxy", requestProxy);
                for (int i = 2; i <= 101; i++) {
                    if (i == 101) {
                        ac1.sendMessage(new GetInsultMessage(ac1, "Proxy"));
                    } else {
                        ac1.sendMessage(new AddActorMessage(ac1, String.valueOf(i)));
                    }
                    sleep(100);
                }
                System.out.println("Waiting the 100 rounds");
                double ini = System.currentTimeMillis();
                while (rounds != 100) {
                    requestProxy.read();
                    rounds++;
                }

                double end = System.currentTimeMillis();
                double time = (double) ((end - ini) / 1000);
                System.out.println("the message has taken " + time + " seconds");
            } else {
                for (int i = 1; i <=50;i++){
                    ac1 = context.lookup(String.valueOf(i));
                    ac1.sendMessage(new QuitMessage(ac1));
                }
                escape = true;
            }
        }
    }

    public void testPingPong() throws InterruptedException {

    }
}