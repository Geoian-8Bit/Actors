package Test;

import Actors.ActorContext;
import Actors.ActorProxy;
import Actors.InsultActor;
import Decorators.EncryptionDecorator;
import Decorators.FirewallDecorator;
import Decorators.LambdaFirewallDecorator;
import Message.AddClosureMessage;
import Message.GetInsultMessage;
import Message.QuitMessage;

import java.util.Scanner;

import static java.lang.Thread.sleep;


public class TestDecorators implements MainInterface{

    public void testRing(){

    }
    public void testPingPong() throws InterruptedException {
        Scanner entrada = new Scanner(System.in);
        int option;
        String name;
        String exit;
        ActorProxy ac1, ac2;
        boolean quit = false;
        boolean escape = false;
        ActorContext context = ActorContext.getInstance();

        while(!escape) {
            System.out.println("Choose the decorator: ");
            System.out.println("[1] Firewall Decorator");
            System.out.println("[2] Lambda Firewall Decorator");
            System.out.println("[3] Encryption Decorator");
            System.out.println("[4] Firewall + Encryption");
            System.out.println("[5] Quit");
            option = entrada.nextInt();
            switch (option) {
                case 1:
                    System.out.println("Choose the name of actor 1");
                    name = entrada.next();
                    ac1 = context.SpawnActor(name, new FirewallDecorator(new InsultActor(name)));
                    System.out.println("Choose the name of actor 2");
                    name = entrada.next();
                    ac2 = context.SpawnActor(name, new FirewallDecorator(new InsultActor(name)));

                    ac1.sendMessage(new GetInsultMessage(ac2, "Activate"));

                    System.out.println("Introduce the name of the unregistered actor");
                    name = entrada.next();
                    ac1.sendMessage(new GetInsultMessage(new ActorProxy(name, new InsultActor(name)), "Activated"));

                    ac1.sendMessage(new QuitMessage(ac1));
                    ac2.sendMessage(new QuitMessage(ac2));
                    break;
                case 2:

                    ac1 = context.SpawnActor("Ping", new LambdaFirewallDecorator<String>(new InsultActor("Ping")));
                    ac2 = context.SpawnActor("Pong", new LambdaFirewallDecorator<String>(new InsultActor("Pong")));

                    System.out.println("To initialize actor system Send one of the following messages");
                    System.out.println("[start, initialize, begin]");
                    name = entrada.next();
                    ac1.sendMessage(new AddClosureMessage<>(ac2, name, (String s) -> { return (s.equals("start") || s.equals("initialize") || s.equals("begin"));}));

                    System.out.println("Press X to stop the test");
                    while (!quit){
                        exit = entrada.nextLine();
                        if(exit.equals("x") || exit.equals("X")) {
                            quit = true;
                            ac1.sendMessage(new QuitMessage(ac1));
                            ac2.sendMessage(new QuitMessage(ac2));
                        }
                        sleep(2000);
                    }
                    sleep(3000);
                    break;
                case 3:
                    quit = false;
                    ac1 = context.SpawnActor("Ping", new EncryptionDecorator(new InsultActor("Ping")));
                    ac2 = context.SpawnActor("Pong", new EncryptionDecorator(new InsultActor("Pong")));

                    ac1.sendMessage(new GetInsultMessage(ac2, "Activate"));

                    System.out.println("Press X to stop the test");
                    while (!quit){
                        exit = entrada.nextLine();
                        if(exit.equals("x") || exit.equals("X")) {
                            quit = true;
                            ac1.sendMessage(new QuitMessage(ac1));
                            ac2.sendMessage(new QuitMessage(ac2));
                        }
                        sleep(2000);
                    }
                    sleep(3000);
                    break;
                case 4:
                    quit = false;
                    ac1 = context.SpawnActor("Ping", new EncryptionDecorator(new FirewallDecorator( new InsultActor("Ping"))));
                    ac2 = context.SpawnActor("Pong", new FirewallDecorator( new EncryptionDecorator(new InsultActor("Pong"))));

                    ac1.sendMessage(new GetInsultMessage(ac2, "Activate"));
                    System.out.println("Actor 1 has firewall encapsulated in Encryption decorator");
                    System.out.println("Actor 1 has encryption encapsulated in Firewall decorator");
                    System.out.println("Press X to stop the test");
                    while (!quit){
                        exit = entrada.nextLine();
                        if(exit.equals("x") || exit.equals("X")) {
                            quit = true;
                            ac1.sendMessage(new QuitMessage(ac1));
                            ac2.sendMessage(new QuitMessage(ac2));
                        }
                        sleep(2000);
                    }
                    sleep(3000);
                    break;
                case 5:
                    escape = true;
                    break;

            }
        }
    }




    }

