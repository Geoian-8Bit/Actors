package Test;

public interface MainInterface {
    public void testRing() throws InterruptedException;
    public void testPingPong () throws InterruptedException;
}
